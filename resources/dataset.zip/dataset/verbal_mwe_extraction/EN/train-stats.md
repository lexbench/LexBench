Statistics EN
=============
### train.cupt
* Sentences: 2150
* Tokens: 35534
* Total VMWEs: 317
  * `IAV`: 22
  * `LVC.cause`: 12
  * `LVC.full`: 98
  * `MVC`: 13
  * `VID`: 44
  * `VPC.full`: 112
  * `VPC.semi`: 16
