Statistics EN
=============
### test.cupt
* Sentences: 3984
* Tokens: 67009
* Total VMWEs: 598
  * `IAV`: 36
  * `LVC.cause`: 29
  * `LVC.full`: 172
  * `MVC`: 29
  * `VID`: 108
  * `VPC.full`: 194
  * `VPC.semi`: 30
