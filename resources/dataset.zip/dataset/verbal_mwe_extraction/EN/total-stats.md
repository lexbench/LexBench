Statistics EN
=============
### TOTAL
* Sentences: 7436
* Tokens: 124203
* Total VMWEs: 1114
  * `IAV`: 71
  * `LVC.cause`: 51
  * `LVC.full`: 333
  * `MVC`: 51
  * `VID`: 187
  * `VPC.full`: 368
  * `VPC.semi`: 53
