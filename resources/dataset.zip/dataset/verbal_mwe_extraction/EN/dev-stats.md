Statistics EN
=============
### dev.cupt
* Sentences: 1302
* Tokens: 21660
* Total VMWEs: 199
  * `IAV`: 13
  * `LVC.cause`: 10
  * `LVC.full`: 63
  * `MVC`: 9
  * `VID`: 35
  * `VPC.full`: 62
  * `VPC.semi`: 7
